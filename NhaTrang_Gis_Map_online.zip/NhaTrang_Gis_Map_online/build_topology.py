import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, MultiPoint
from shapely.ops import split
import numpy as np

# LOAD DATA
roads = gpd.read_file(
"static/data/roads_nhatrang.geojson"
).to_crs(epsg=32649)

pois = gpd.read_file(
"static/data/pois_nhatrang.geojson"
).to_crs(epsg=32649)

print("Roads:", len(roads))
print("POIs :", len(pois))

# THAM SỐ
SNAP_TOL = 0.5

# THU THẬP NODE
node_points = []

# Thu thập điểm POI

for geom in pois.geometry:
    if geom is not None and not geom.is_empty:
        node_points.append(geom)

print("POI nodes:", len(node_points))

# Thu thập điểm đầu cuối của đường
for line in roads.geometry:

    if line.geom_type != "LineString":
        continue

    coords = list(line.coords)

    node_points.append(
        Point(coords[0])
    )

    node_points.append(
        Point(coords[-1])
    )
print("Nodes after endpoints:", len(node_points))

# ROAD INTERSECTIONS
roads_list = roads.geometry.tolist()

for i in range(len(roads_list)):
    for j in range(i + 1, len(roads_list)):
        try:
            inter = roads_list[i].intersection(
                roads_list[j]
            )
            if inter.is_empty:
                continue

            if inter.geom_type == "Point":

                node_points.append(inter)

            elif inter.geom_type == "MultiPoint":

                for p in inter.geoms:
                    node_points.append(p)

        except:
            continue

    print("Nodes after intersections:", len(node_points))

# REMOVE DUPLICATES
unique_nodes = {}

for p in node_points:

    key = (
        round(p.x, 1),
        round(p.y, 1)
    )

    unique_nodes[key] = p

node_points = list(
    unique_nodes.values()
)

print("Unique nodes:", len(node_points))

# NODE DATAFRAME
nodes = gpd.GeoDataFrame(
geometry=node_points,
crs=roads.crs
)

nodes["node_id"] = range(
len(nodes)
)

nodes["x"] = nodes.geometry.x
nodes["y"] = nodes.geometry.y

print("Nodes final:", nodes.head())

# HÀM TÌM NODE GẦN NHẤT
node_xy = nodes[
["x", "y"]
].to_numpy()

def nearest_node(point):

    dx = node_xy[:, 0] - point.x
    dy = node_xy[:, 1] - point.y

    dist = np.hypot(dx, dy)
    idx = dist.argmin()

    return int(
        nodes.iloc[idx]["node_id"]
    )

# SPLIT ROADS
edges_data = []

edge_id = 0

for road in roads.geometry:
    try:

        split_points = []

        for point in node_points:

            if road.distance(point) < SNAP_TOL:
                snap_point = road.interpolate(
                    road.project(point)
                )
                split_points.append(
                    snap_point
                )

        if len(split_points) < 2:
            continue
        
        split_geom = split(

            road,

            MultiPoint(split_points)

        )

        for seg in split_geom.geoms:

            if seg.length < 0.01:
                continue

            start_point = Point(
                seg.coords[0]
            )

            end_point = Point(
                seg.coords[-1]
            )

            start_node = nearest_node(
                start_point
            )

            end_node = nearest_node(
                end_point
            )

            if start_node == end_node:
                continue

            edges_data.append({

                "edge_id": edge_id,

                "start_node": start_node,

                "end_node": end_node,

                "length": float(
                    seg.length
                ),

                "geometry": seg

            })

            edge_id += 1

    except:
        continue

    print("Edges:", len(edges_data))

# EDGE GDF
edges_gdf = gpd.GeoDataFrame(
edges_data,
geometry="geometry",
crs=roads.crs
)
print(edges_gdf.head())

# CSV
edges_csv = pd.DataFrame({

    "edge_id":
        edges_gdf["edge_id"],

    "start_node":
        edges_gdf["start_node"],

    "end_node":
        edges_gdf["end_node"],

    "length":
        edges_gdf["length"]
    })

# CHỈ GIỮ NODE ĐƯỢC SỬ DỤNG
used_nodes = set(
edges_csv["start_node"]
)

used_nodes.update(
edges_csv["end_node"]
)

nodes = nodes[
nodes["node_id"].isin(
used_nodes
)
].copy()

# EXPORT CSV
nodes[["node_id", "x", "y"]].to_csv(
    "nodes.csv",
    index=False
    )

edges_csv.to_csv(
    "edges.csv",
    index=False
    )

# EXPORT GEOJSON
nodes.to_crs(4326).to_file(
    "nodes.geojson",
    driver="GeoJSON"
    )

edges_gdf.to_crs(4326).to_file(
    "edges.geojson",
    driver="GeoJSON"
    )

print("Saved nodes.csv")
print("Saved edges.csv")
print("Saved nodes.geojson")
print("Saved edges.geojson")
