# MPORT THƯ VIỆN
from flask import Flask, json, render_template, request, jsonify
from flask import jsonify
from flask import request

import pandas as pd
import geopandas as gpd
import networkx as nx
import numpy as np

from shapely.geometry import Point

# KHỞI TẠO FLASK
app = Flask(__name__)

# ĐỌC DỮ LIỆU
nodes = pd.read_csv("nodes.csv")
edges = pd.read_csv("edges.csv")

roads = gpd.read_file("static/data/roads_nhatrang.geojson")
pois = gpd.read_file("static/data/pois_nhatrang.geojson")

nodes_geojson = gpd.read_file("nodes.geojson")
edges_geojson = gpd.read_file("edges.geojson")

# CHUYỂN CRS
from pyproj import Transformer

transformer = Transformer.from_crs(
    "EPSG:32649",
    "EPSG:4326",
    always_xy=True
)

pois = pois.to_crs(4326)
roads = roads.to_crs(4326)

# BUILD GRAPH
G = nx.Graph()

for _, row in edges.iterrows():

    G.add_edge(

        int(row["start_node"]),
        int(row["end_node"]),

        weight=float(
            row["length"]
        ),

        edge_id=int(
            row["edge_id"]
        )
    )

print("Nodes:",G.number_of_nodes())
print("Edges:",G.number_of_edges())

print(
    "CSV Nodes:",
    len(nodes)
)

isolated = len(nodes) - G.number_of_nodes()

print(
    "Isolated Nodes:",
    isolated
)

# CHUYỂN CRS CHO SNAP TO GRAPH
transformer_to_utm = Transformer.from_crs(
    "EPSG:4326",
    "EPSG:32649",
    always_xy=True
)

# SNAP TO GRAPH
def snap_to_graph(lat, lon):
    x, y = transformer_to_utm.transform(
        lon,
        lat
    )

    connected_nodes = nodes[
        nodes["node_id"].isin(
            list(G.nodes)
        )
    ]

    distances = np.sqrt(
        (connected_nodes["x"] - x) ** 2
        +
        (connected_nodes["y"] - y) ** 2
    )
    idx = distances.idxmin()

    return (
        int(connected_nodes.loc[idx, "node_id"]),
        float(connected_nodes.loc[idx, "y"]),
        float(connected_nodes.loc[idx, "x"])
    )

# BUILD ROUTE GEOMETRY
def build_route_geometry(route):
    coords = []

    for node_id in route:

        node = nodes[
            nodes["node_id"] == node_id
        ].iloc[0]

        lon, lat = transformer.transform(
            node["x"],
            node["y"]
        )

        coords.append([
            lat,
            lon
        ])

    return coords

# HOME PAGE
@app.route("/")
def index():

    return render_template("index.html")

# API TÌM ĐƯỜNG
@app.route("/route",methods=["POST"])
def route():

    try:

        data = request.json

        start_lat = data["start_lat"]
        start_lon = data["start_lon"]

        end_lat = data["end_lat"]
        end_lon = data["end_lon"]

        start_node, _, _ = snap_to_graph(
            start_lat,
            start_lon
        )

        end_node, _, _ = snap_to_graph(
            end_lat,
            end_lon
        )

        if start_node not in G.nodes:

            return jsonify({
                "status":"error",
                "message":f"Start node {start_node} not in graph"
            })

        if end_node not in G.nodes:

            return jsonify({
                "status":"error",
                "message":f"End node {end_node} not in graph"
            })
        
        route_path = nx.shortest_path(
            G,
            source=start_node,
            target=end_node,
            weight="weight"
        )

        distance = nx.shortest_path_length(
            G,
            source=start_node,
            target=end_node,
            weight="weight"
        )

        route_coords = build_route_geometry(
            route_path
        )

        return jsonify({
            "status":"success",
            "distance":round(
                distance/1000,
                2
            ),

            "route":route_coords
        })

    except Exception as e:

        return jsonify({
            "status":"error",
            "message":str(e)
        })

# CHỈ GIỮ CÁC POI PHỤC VỤ WEB GIS
allowed_fclass = [
    "hospital",
    "pharmacy",
    "school",
    "university",
    "cafe",
    "restaurant",
    "bank",
    "atm",
    "hotel",
    "supermarket",
    "fast_food"
]

pois = pois[
    pois["fclass"]
    .astype(str)
    .str.lower()
    .isin(allowed_fclass)
]

print("\nPOI sau khi lọc:")
print(pois["fclass"].value_counts())

# API LẤY LOẠI POI   
@app.route("/poi_types")
def poi_types():

    types = sorted(
        pois["fclass"]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    return jsonify({
        "status":"success",
        "types":types
    })

# API TÌM POI GẦN NHẤT
@app.route(
    "/nearest_poi",
    methods=["POST"]
)
def nearest_poi():

    try:
        data = request.json
        lat = data["lat"]
        lon = data["lon"]
        poi_type = data["type"]

        filtered = pois[
            pois["fclass"]
            .astype(str)
            .str.lower()
            ==
            poi_type.lower()

        ]

        if len(filtered) == 0:

            return jsonify({
                "status":"error",
                "message":"No POI"
            })

# Ánh xạ vị trí người dùng lên mạng giao thông
        start_node, _, _ = snap_to_graph(
            lat,
            lon
        )

        best_dist = float("inf")
        best_route = None
        best_poi = None

# Ánh xạ từng POI lên mạng giao thông
        for _, row in filtered.iterrows():

            dest_node, _, _ = snap_to_graph(

                row.geometry.y,
                row.geometry.x
            )

            try:
                dist = nx.shortest_path_length(
                    G,
                    source=start_node,
                    target=dest_node,
                    weight="weight"
                )

                if dist < best_dist:
                    best_dist = dist
                    best_route = nx.shortest_path(

                        G,
                        source=start_node,
                        target=dest_node,
                        weight="weight"
                    )
                    best_poi = row

            except:
                continue
        if best_poi is None:

            return jsonify({
                "status":"error",
                "message":"No route"
            })

        route_coords = build_route_geometry(best_route)
        route_coords.append([best_poi.geometry.y,best_poi.geometry.x])

        return jsonify({
            "status":"success",
            "poi_name":str(
                best_poi["name"]
            ),
            "poi_lat":float(
                best_poi.geometry.y
            ),
            "poi_lon":float(
                best_poi.geometry.x
            ),
            "distance":round(
                best_dist/1000,
                2
            ),
            "route":route_coords
        })

    except Exception as e:

        return jsonify({
            "status":"error",
            "message":str(e)
        })

# API LẤY TOPOLOGY    
@app.route("/topology")
def topology():

    return jsonify({

        "nodes":
        json.loads(
            nodes_geojson.to_json()
        ),

        "edges":
        json.loads(
            edges_geojson.to_json()
        )
    })

# CHẠY ỨNG DỤNG   
if __name__ == "__main__":

    app.run(

        host="0.0.0.0",

        port=5000,

        debug=True

    )