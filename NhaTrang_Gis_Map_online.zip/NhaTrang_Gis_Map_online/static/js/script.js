// ======================================
// CREATE MAP
// ======================================

var map = L.map('map').setView([12.2388, 109.1967], 13);

// ======================================
// BASEMAP
// ======================================

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 19
}).addTo(map);

// ======================================
// CUSTOM ICONS
// ======================================

var startIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

var endIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

var poiIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

// ======================================
// VARIABLES
// ======================================

var startPoint = null;
var endPoint = null;
var startMarker = null;
var endMarker = null;
var routeLayer = null;
var poiMarker = null;

// ======================================
// LOAD POI TYPES ON START
// ======================================

function loadPoiTypes() {
    fetch("/poi_types")
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                var select = document.getElementById("poiType");
                select.innerHTML = "";
                
                data.types.forEach(type => {
                    var option = document.createElement("option");
                    option.value = type;
                    option.textContent = getEmoji(type) + " " + type.charAt(0).toUpperCase() + type.slice(1);
                    select.appendChild(option);
                });
            }
        })
        .catch(err => console.error(err));
}

function loadTopology() {
    fetch("/topology")
        .then(res => res.json())
        .then(data => {
            L.geoJSON(
                data.edges
            ).addTo(map);

            L.geoJSON(
                data.nodes
            ).addTo(map);
        });
}

function getEmoji(type) {
    var emojis = {
        "hospital": "🏥", "pharmacy": "💊",
        "school": "🏫", "university": "🎓", "cafe": "☕",
        "restaurant": "🍽️", "fast_food": "🍔",
        "bank": "🏦", "atm": "💳"  
    };
    return emojis[type] || "📍";
}

// ======================================
// MAP CLICK
// ======================================

map.on("click", function(e) {
    if (!startPoint) {
        startPoint = e.latlng;
        startMarker = L.marker(startPoint, {icon: startIcon})
            .addTo(map).bindPopup("📍 Điểm xuất phát").openPopup();
        document.getElementById("statusBox").textContent = "Click chọn điểm đến";
    } 
    else if (!endPoint) {
        endPoint = e.latlng;
        endMarker = L.marker(endPoint, {icon: endIcon})
            .addTo(map).bindPopup("🏁 Điểm đến").openPopup();
        calculateRoute();
    } 
    else {
        resetMap();
        startPoint = e.latlng;
        startMarker = L.marker(startPoint, {icon: startIcon})
            .addTo(map).bindPopup("📍 Điểm xuất phát").openPopup();
        document.getElementById("statusBox").textContent = "Click chọn điểm đến";
    }
});

// ======================================
// CALCULATE ROUTE
// ======================================

function calculateRoute() {
    showLoading("Đang tính đường đi...");
    
    fetch("/route", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            start_lat: startPoint.lat,
            start_lon: startPoint.lng,
            end_lat: endPoint.lat,
            end_lon: endPoint.lng
        })
    })
    .then(res => res.json())
    .then(data => {
        hideLoading();
        
        if (data.status === "success") {
            if (routeLayer) map.removeLayer(routeLayer);
            
            routeLayer = L.polyline(data.route, {color: "red", weight: 5}).addTo(map);
            map.fitBounds(routeLayer.getBounds(),
                {
                padding:[50,50],
                maxZoom:16
                }
            );
            
            document.getElementById("distanceBox").textContent = data.distance + " km";
            document.getElementById("statusBox").textContent = "Hoàn tất!";
        } else {
            document.getElementById("statusBox").textContent = "Lỗi: " + data.message;
            alert(data.message);
        }
    })
    .catch(err => {
        hideLoading();
        document.getElementById("statusBox").textContent = "Lỗi kết nối!";
    });
}

// ======================================
// FIND NEAREST POI
// ======================================

function findNearest() {
    if (!startPoint) {
        alert("Vui lòng click chọn vị trí xuất phát trước!");
        return;
    }
    
    var type = document.getElementById("poiType").value;
    showLoading("Đang tìm " + type + "...");
    
    fetch("/nearest_poi", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            lat: startPoint.lat,
            lon: startPoint.lng,
            type: type
        })
    })
    .then(res => res.json())
    .then(data => {
        hideLoading();
        
        if (data.status === "success") {
            if (routeLayer) map.removeLayer(routeLayer);
            if (poiMarker) map.removeLayer(poiMarker);
            
            routeLayer = L.polyline(data.route, {color: "blue", weight: 5}).addTo(map);
            
            poiMarker = L.marker([data.poi_lat, data.poi_lon], {icon: poiIcon})
                .addTo(map)
                .bindPopup("<b>" + data.poi_name + "</b><br>Khoảng cách: " + data.distance + " km")
                .openPopup();
            
            map.fitBounds(routeLayer.getBounds(),
                {
                padding:[50,50],
                maxZoom:16
                }
            );
            
            document.getElementById("distanceBox").textContent = data.distance + " km";
            document.getElementById("statusBox").textContent = "Tìm thấy: " + data.poi_name;
        } else {
            document.getElementById("statusBox").textContent = "Lỗi: " + data.message;
        }
    })
    .catch(err => {
        hideLoading();
        document.getElementById("statusBox").textContent = "Lỗi kết nối!";
    });
}

// ======================================
// RESET
// ======================================

function resetMap() {
    if (startMarker) map.removeLayer(startMarker);
    if (endMarker) map.removeLayer(endMarker);
    if (routeLayer) map.removeLayer(routeLayer);
    if (poiMarker) map.removeLayer(poiMarker);
    
    startPoint = null;
    endPoint = null;
    startMarker = null;
    endMarker = null;
    routeLayer = null;
    poiMarker = null;
    
    document.getElementById("distanceBox").textContent = "0 km";
    document.getElementById("statusBox").textContent = "Sẵn sàng";
}

// ======================================
// GET CURRENT LOCATION
// ======================================

function getCurrentLocation() {
    if (!navigator.geolocation) {
        alert("Trình duyệt không hỗ trợ định vị!");
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            map.setView([lat, lng], 15);
            resetMap();
            
            startPoint = L.latLng(lat, lng);
            startMarker = L.marker(startPoint, {icon: startIcon})
                .addTo(map).bindPopup("📍 Vị trí của bạn").openPopup();
            
            document.getElementById("statusBox").textContent = "Đã định vị - click chọn điểm đến";
        },
        function(error) {
            alert("Lỗi định vị!");
        }
    );
}

// ======================================
// LOADING
// ======================================

function showLoading(message) {
    var loading = document.getElementById("loading");
    loading.querySelector("p").textContent = message;
    loading.classList.remove("hidden");
}

function hideLoading() {
    document.getElementById("loading").classList.add("hidden");
}

// ======================================
// INIT
// ======================================

document.addEventListener("DOMContentLoaded", function() {
    loadPoiTypes();
});